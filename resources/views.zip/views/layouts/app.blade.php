<!doctype html>
<html class="no-js" lang="">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
		{!! SEOMeta::generate() !!}
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="manifest" href="site.webmanifest">
		<link rel="icon" type="image/webp" href="{{asset('images/SMUK LOGO_PNG.webp')}}" sizes="16x16">
        <!-- Place favicon.ico in the root directory -->

		<!-- CSS here -->
        <link rel="stylesheet" href="{{asset('css/bootstrap.min.css')}}">
        <link rel="stylesheet" href="{{asset('css/owl.carousel.min.css')}}">
        <link rel="stylesheet" href="{{asset('css/animate.min.css')}}">
        <link rel="stylesheet" href="{{asset('css/meanmenu.css')}}">
        <link rel="stylesheet" href="{{asset('css/magnific-popup.css')}}">
        <link rel="stylesheet" href="{{asset('css/fontawesome-all.min.css')}}">
        <link rel="stylesheet" href="{{asset('css/slick.css')}}">
        <link rel="stylesheet" href="{{asset('css/default.css')}}">
        <link rel="stylesheet" href="{{asset('css/style.css')}}">
        <link rel="stylesheet" href="{{asset('css/responsive.css')}}">

        <script src="https://cdn.jsdelivr.net/npm/vue/dist/vue.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/vee-validate@<3.0.0/dist/vee-validate.js"></script>
        <script src="https://unpkg.com/vue-currency-input"></script>
        
        <!-- Google Tag Manager (noscript) -->
        <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-55NLH5D"
        height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
        <!-- End Google Tag Manager (noscript) -->
        
        <!-- Google Tag Manager -->
        <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
        'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
        })(window,document,'script','dataLayer','GTM-55NLH5D');</script>
        <!-- End Google Tag Manager -->
    </head>
    <body>
		<!-- header-start -->
		<header>
			<!-- header-top-area-start -->
			<!--<div class="header-top-area header-white">
				<div class="container">
					<div class="row">
						<div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
							<ul class="header-wrapper">
								<li>
									<div class="header-icon">
										<i class="fas fa-phone"></i>
									</div>
									<div class="header-text">
										<a href="#">01743 562862</a>
									</div>
								</li>
								<li>
									<div class="header-icon">
										<i class="fas fa-envelope"></i>
									</div>
									<div class="header-text">
										<a href="#"><span class="__cf_email__" data-cfemail="1c6f696c6c736e685c7b717d7570327f7371">info@smartmortages</span></a>
									</div>
								</li>
							</ul>
						</div>
						<div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
							<div class="header-right-wrapper">
								<ul class="headers-icon">
									<li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
									<li><a href="#"><i class="fab fa-twitter"></i></a></li>
									<li><a href="#"><i class="fab fa-google-plus-g"></i></a></li>
									<li><a href="#"><i class="fab fa-skype"></i></a></li>
								</ul>
							</div>
						</div>
					</div>
				</div> 
			</div> -->
			<!-- header-top-area-end -->
			<div class="header-menu">
				<div class="container">
					<div class="row">
						<div class="col-xl-3 col-lg-3">
							<div class="logo">
								<a href="{{url('/')}}"><img id="comp-kb980ox52imgimage" style="object-position:50% 50%;width:300px;height:65px;object-fit:contain" alt="SMUK LOGO.PNG" data-type="image" itemprop="image" src="https://static.wixstatic.com/media/83d864_92c810fd334b4db69306ab77f8cb987f~mv2.png/v1/fill/w_320,h_85,al_c,q_85,usm_0.66_1.00_0.01/SMUK%20LOGO_PNG.webp"></a>
							</div>
						</div>
						<div class="col-xl-9 col-lg-9">
							<div class="header-button d-none d-sm-none d-md-none d-lg-block">
								<a class="btn btn-border" href="{{url('mortgages')}}">More <i class="fas fa-long-arrow-alt-right"></i></a>
							</div>
                           <div class="main-menu text-center">
								<nav id="mobile-menu">
									<ul>
										<li class="active">
											<a href="{{url('/')}}">home</a>
											<ul class="submenu">
												<li>
													<a href="{{url('about')}}"> About Us</a>
												</li>
												<li>
													<a href="{{url('contact')}}"> Contact Us</a>
												</li>
												<li>
													<a href="{{url('resources')}}"> Resources</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#">Remortgages</a>
											<ul class="submenu">
												<li>
													<a href="{{url('mortgages/' .$url = 'debt-consolidation-mortgage')}}"> Debt Consolidation Mortgages</a>
												</li>
												<li>
													<a href="{{url('mortgages/' .$url = 'bad-credit-mortgage')}}"> Bad Credit Mortgages</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#">Secured Loans </a>
											<ul class="submenu">
												<li>
													<a href="{{url('secured-loan/' .$url = 'home-owner-loans')}}"> Home Owner Loans </a>
												</li>
												<li>
													<a href="{{url('secured-loan/' .$url = 'bad-credit-secured-loans')}}"> Bad Credit Secured Loans</a>
												</li>
											</ul>
										<li>
											<a href="#">Buy to Let</a>
											<ul class="submenu">
												<li>
													<a href="{{url('mortgages/' .$url = 'buy-to-let-mortgages')}}"> Buy to Let Mortgages </a>
												</li>
												<li>
													<a href="{{url('mortgages/' .$url = 'right-to-buy-mortgage')}}"> Right to Buy Mortgages</a>
												</li>
												<li>
													<a href="{{url('mortgages/' .$url = 'let-to-buy-mortgage')}}"> Let to Buy Mortgages</a>
												</li>
												<li>
													<a href="{{url('mortgages/' .$url = 'help-to-buy-mortgage')}}"> Help to Buy Mortgages</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#">House Purchase</a>
											<ul class="submenu">
												<li>
													<a href="{{url('mortgages/' .$url = 'home-improvement-mortgage')}}"> Home Improvement</a>
												</li>
										</li>
									</ul>
								</nav>
						   </div>
							<div class="mobile-menu"></div>
                       </div>
					</div>
				</div>
			</div>
		</header>
            @yield('content')
        		<!-- footer-start -->
		<footer>
			<div class="footer-top-area footer-white gray-bg pt-110">
				<div class="container">
					<div class="footer-border pb-45">
						<div class="row">
						<div class="col-xl-4 col-lg-4 col-md-6 col-sm-12">
							<div class="footer-wrapper mb-30">
								<div class="footer-logo">
									<a href="{{url('/')}}"><img id="comp-kb980ox52imgimage" style="object-position:50% 50%;width:300px;height:65px;object-fit:contain" alt="SMUK LOGO.PNG" data-type="image" itemprop="image" src="https://static.wixstatic.com/media/83d864_92c810fd334b4db69306ab77f8cb987f~mv2.png/v1/fill/w_320,h_85,al_c,q_85,usm_0.66_1.00_0.01/SMUK%20LOGO_PNG.webp"></a>
								</div>
								<div class="footer-text">
									<p>JMM Financial t/a Smart Mortgages UK is an appointed representative of HL Partnership Limited, which is authorised and regulated by the Financial Conduct Authority.</p>
								</div>
								<!--<ul class="footer-icon">
									<li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
									<li><a href="#"><i class="fab fa-twitter"></i></a></li>
									<li><a href="#"><i class="fab fa-google-plus-g"></i></a></li>
									<li><a href="#"><i class="fab fa-pinterest-p"></i></a></li>
									<li><a href="#"><i class="fab fa-skype"></i></a></li>
								</ul>-->
							</div>
						</div>
						<div class="col-xl-4 col-lg-4 col-md-6 col-sm-12">
							<div class="footer-wrapper mb-30">
								<h3 class="footer-title">Quick Links</h3>
								<ul class="footer-menu">
									<li><a href="{{url('about')}}">About Us</a></li>
                                    <!--<li><a href="{{url('contact')}}">Contact Us</a></li>-->
                                    <li><a href="{{url('remortgage-calculator')}}">Calculator</a></li>
								</ul>
							</div>
						</div>
						<div class="col-xl-4 col-lg-4 col-md-6 col-sm-12">
							<div class="footer-wrapper mb-30">
								<h3 class="footer-title">History</h3>
								<ul class="recent-menu">
									<li>
										<div class="recent-info">
											<span>05 May 2018</span>
										</div>
									</li>
								</ul>
							</div>
						</div>
					</div>
					</div>
					<!-- <div class="footer-icon-area pt-40 pb-10">
						<div class="row">
							<div class="col-xl-4 col-lg-4 col-md-4 col-sm-6">
								<div class="footer-icon-wrapper mb-30">
									<div class="footers-icon">
										<a href="#"><i class="fas fa-phone"></i></a>
									</div>
									<div class="footer-icon-text">
										<h4>call us</h4>
										<span>01743 562862</span>
									</div>
								</div>
							</div>
							<div class="col-xl-4 col-lg-4 col-md-4 col-sm-6">
								<div class="footer-icon-wrapper pl-30 mb-30">
									<div class="footers-icon">
										<a href="#"><i class="fas fa-envelope"></i></a>
									</div>
									<div class="footer-icon-text">
										<h4>Email Us</h4>
										<span><a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="32414742425d404672555f535b5e1c515d5f">info@smartmortgages.com</a></span>
									</div>
								</div>
							</div>
							<div class="col-xl-4 col-lg-4 col-md-4 d-sm-none d-md-block">
								<div class="footer-icon-wrapper pl-80 mb-30">
									<div class="footers-icon">
										<a href="#"><i class="fas fa-home"></i></a>
									</div>
									<div class="footer-icon-text">
										<h4>Location</h4>
										<span> First Floor Suit C2, Haughmond View, Shrewsbury Business Park, Shrewsbury, SY2 6LG</span>
									</div>
								</div>
							</div>
						</div>
					</div> -->
					<div class="footer-bottom-area pt-20 pb-20">
						<div class="row">
							<div class="col-xl-12">
								<div class="copyright text-center">
									<p>Copyright <i class="far fa-copyright"></i> 2020 Smartmortgages</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</footer>
		<!-- footer-end -->


		<!-- JS here -->
        <script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="js/vendor/modernizr-3.5.0.min.js"></script>
        <script src="{{asset('js/vendor/jquery-1.12.4.min.js')}}"></script>
        <script src="{{asset('js/popper.min.js')}}"></script>
        <script src="{{asset('js/bootstrap.min.js')}}"></script>
        <script src="{{asset('js/jquery.meanmenu.js')}}"></script>
        <script src="{{asset('js/owl.carousel.min.js')}}"></script>
        <script src="{{asset('js/isotope.pkgd.min.js')}}"></script>
        <script src="{{asset('js/waypoints.min.js')}}"></script>
		<script src="{{asset('js/jquery.counterup.min.js')}}"></script>
		<script src="{{asset('js/jquery.nice-select.min.js')}}"></script>
        <script src="{{asset('js/slick.min.js')}}"></script>
        <script src="{{asset('js/ajax-form.js')}}"></script>
        <script src="{{asset('js/jquery.easypiechart.min.js')}}"></script>
        <script src="{{asset('js/wow.min.js')}}"></script>
        <script src="{{asset('js/jquery.scrollUp.min.js')}}"></script>
        <script src="{{asset('js/imagesloaded.pkgd.min.js')}}"></script>
        <script src="{{asset('js/jquery.magnific-popup.min.js')}}"></script>
        <script src="{{asset('js/plugins.js')}}"></script>
        <script src="{{asset('js/main.js')}}"></script>
    </body>
</html>
