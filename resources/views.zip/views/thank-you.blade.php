@extends('layouts.app')

@section('content')
<!-- breadcrumb-area-start -->
		<div class="breadcrumb-area pt-245 pb-245 " style="background-image:url(/img/bg/bg9.jpg)">
			<div class="container">
				<div class="row">
					<div class="col-xl-12">
						<div class="breadcrumb-wrapper text-center">
							<div class="breadcrumb-text">
							<h1>Thank you</h1>
							</div>
							<div class="breadcrumb-menu mt-20">
								<ul>
									<li><a href="{{url('/')}}">We have received your quote, we will be in touch</a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
@endsection